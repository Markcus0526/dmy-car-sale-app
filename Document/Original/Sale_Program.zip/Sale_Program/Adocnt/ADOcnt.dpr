program ADOcnt;

uses
  Forms,
  dbfmu in 'pas\dbfmu.pas' {dbfm};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(Tdbfm, dbfm);
  Application.Run;
end.
