object dbfm: Tdbfm
  Left = 301
  Top = 183
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  ClientHeight = 200
  ClientWidth = 311
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object dd: TSpeedButton
    Left = 186
    Top = 155
    Width = 103
    Height = 22
    Caption = #23436'    '#25104
    Font.Charset = GB2312_CHARSET
    Font.Color = clWindowText
    Font.Height = -14
    Font.Name = #23435#20307
    Font.Style = []
    ParentFont = False
    OnClick = ddClick
  end
  object Label3: TLabel
    Left = 9
    Top = 21
    Width = 42
    Height = 14
    Caption = #26381#21153#22120
    Font.Charset = ANSI_CHARSET
    Font.Color = clBlue
    Font.Height = -14
    Font.Name = #23435#20307
    Font.Style = []
    ParentFont = False
  end
  object Label1: TLabel
    Left = 12
    Top = 111
    Width = 28
    Height = 14
    Caption = #29992#25143
    Font.Charset = ANSI_CHARSET
    Font.Color = clBlue
    Font.Height = -14
    Font.Name = #23435#20307
    Font.Style = []
    ParentFont = False
  end
  object Label6: TLabel
    Left = 13
    Top = 160
    Width = 28
    Height = 14
    Caption = #23494#30721
    Font.Charset = ANSI_CHARSET
    Font.Color = clBlue
    Font.Height = -14
    Font.Name = #23435#20307
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 9
    Top = 66
    Width = 42
    Height = 14
    Caption = #25968#25454#24211
    Font.Charset = ANSI_CHARSET
    Font.Color = clBlue
    Font.Height = -14
    Font.Name = #23435#20307
    Font.Style = []
    ParentFont = False
  end
  object BitBtn1: TBitBtn
    Left = 186
    Top = 104
    Width = 103
    Height = 25
    Caption = 'ADO'#21442#25968#37197#32622
    Font.Charset = GB2312_CHARSET
    Font.Color = clWindowText
    Font.Height = -14
    Font.Name = #23435#20307
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    OnClick = BitBtn1Click
  end
  object eip: TEdit
    Left = 57
    Top = 16
    Width = 103
    Height = 22
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -14
    Font.Name = #23435#20307
    Font.Style = []
    ImeName = #20013#25991' ('#31616#20307') - '#24494#36719#25340#38899
    ParentFont = False
    TabOrder = 1
  end
  object esa: TEdit
    Left = 57
    Top = 108
    Width = 103
    Height = 21
    ImeName = #20013#25991' ('#31616#20307') - '#24494#36719#25340#38899
    TabOrder = 2
    Text = 'sa'
  end
  object ep: TEdit
    Left = 56
    Top = 156
    Width = 104
    Height = 21
    ImeName = #20013#25991' ('#31616#20307') - '#24494#36719#25340#38899
    TabOrder = 3
  end
  object edb: TEdit
    Left = 56
    Top = 62
    Width = 105
    Height = 21
    ImeName = #20013#25991' ('#31616#20307') - '#24494#36719#25340#38899
    TabOrder = 4
    Text = 'carxsdb'
  end
end
