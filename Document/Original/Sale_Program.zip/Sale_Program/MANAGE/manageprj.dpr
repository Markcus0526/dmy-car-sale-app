program manageprj;

uses
  Forms,
  mainu in 'deleteAll\mainu.pas' {fmmain},
  comback in 'deleteAll\Comback.pas' {fmcomback},
  managedmu in 'dm\managedmu.pas' {managedm: TDataModule},
  defvar in 'var\Defvar.pas',
  dmvar in 'var\Dmvar.pas',
  stringVar in 'var\stringVar.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(Tfmmain, fmmain);
  Application.CreateForm(Tfmcomback, fmcomback);
  Application.CreateForm(Tmanagedm, managedm);
  Application.Run;
end.
