unit stringVar;

interface
uses Windows, Messages, SysUtils, Classes, extctrls,Graphics, Controls, Forms, Dialogs,
     DBTables, Db, ImgList, ActnList,comctrls,inifiles,lzexpand,Excel2000,ExcelXP,StdCtrls,ADODB, DBGrids;

procedure addcomboxpd(cbox : tcombobox);
procedure loadcomboxpd(cbox : Tcombobox; txt : string);
procedure savecomboxpd(cbox : Tcombobox;txt : string);
procedure delcomboxpd(cbox : tcombobox);
procedure CBchange(resultCB:Tcombobox;CB:Tcombobox);
procedure AddnotRepeatCB(itemtext:string;CB:Tcombobox);

//�õ����ж�����
function getStrcount(s:string):integer;
function FmatIntLen(vl,ln:integer):string;
function addintstrLNfu(st:string;ln:integer):string;
function addintstrfu(st:string):string;
function sltfu(var s : string) : string;
function sltDvcfu(var s : string) : string;

function ADDjlhFU(var jlh ,id : Integer) :string;
//������ڸ�ʽ
function getstr(str:string):string;
//���ַ�����ĳһ�ض��ַ�ȫ��ɾ��
function DelSubstr(const SubStr,s : string): string;
//�ַ����в���ĳһ�ַ��Ӵ��ĸ���
function  CountConstS(const s : string;sourStr : string) : integer;
//�ַ����в���ĳһ�ַ��Ӵ��Ĵ��ڵڼ�λ 1��2��3��4��5
function  NumConstS(const substr : string;sourStr : string) : integer;
procedure AddnotRepeatRG(itemtext:string;rg:Tradiogroup);
function  SltLevelfu(s : string;ik:integer) : string;
function  addaftspfu(s:string;i:integer):string;
function  addbefspfu(s:string;i:integer):string;
procedure getCBtext(txt:string;cb:Tcombobox);
function getyear(vdate:Tdatetime):string;
procedure showMsg(s:string);
procedure DBtoExcel(ExceltemplatePath:string;Eapp:Texcelapplication;Esheet:Texcelworksheet;Adoquy:Tadoquery;Grid:Tdbgrid;firstcol,lastcol:integer);
function loadfromzd(items:Tstrings;road:string):string;
var
   jlh,id:integer;
Const
   Orignwidth=800;
   Orignheight=600;
function ReScaleFu(Frm:Tform):boolean;
implementation

uses defVar;
//�ı�ֱ��ʣ�ͬʱ����ؼ�Ҳ�ı�
function ReScaleFu(Frm:Tform):boolean;
var
  FWidth:integer;
begin
 with Frm do
 begin
   if(Screen.width <> Orignwidth)then
    begin
      FWidth:=Width;
      Scaled:=TRUE;
      Font.Size:=(Width DIV FWidth)*Font.Size;//�����С����
      ScaleBy(Screen.Width,Orignwidth); //�ؼ���С����
      Height:=longint(Height)*longint(Screen.Height) DIV Orignheight;
      Width:=longint(Width)*longint(Screen.Width) DIV Orignwidth;//���ڴ�С����
      result := true;
    end
    else result:=false;
  end;  
end;
function loadfromzd(items:Tstrings;road:string):string;
begin
   if fileExists(road)=false
   then begin
          result:='fail';exit;
          end
   else begin
          items.LoadFromFile(road);
          result:='success';
          end;
end;

function addbefspfu(s:string;i:integer):string;
var g : string;
begin
  if length(s) < i
  then begin
	 repeat
	   s:= ' ' + s ;
	 until (length(s) >= i);
	 g := s ;
       end
  else g := copy(s,1,i);
  result := g ;
end;

function SltLevelfu(s : string;ik:integer) : string;
var i,k : integer;
    st  : string;
begin
  k := 1;
  st := s;
  while k < ik do
  begin
    i := pos(Dvc,st);
    delete(st,1,i);
    inc(k);
  end;
  i := pos(Dvc,st);
  result := copy(st,1,i-1);
end;
procedure AddnotRepeatRG(itemtext:string;rg:Tradiogroup);
begin
   if rg.Items.IndexOf(itemtext)<0
   then
   rg.items.add(itemtext);
end;
procedure AddnotRepeatCB(itemtext:string;CB:Tcombobox);
begin
   if cb.Items.IndexOf(itemtext)<0
   then
   CB.items.add(itemtext);
end;
function sltfu(var s : string) : string;
var i  : integer;
begin
  i := pos(',',s);
  result := copy(s,1,i-1);
  delete(s,1,i);
end;
procedure addcomboxpd(cbox : tcombobox);
begin
  if ( CBox.Items.IndexOf(CBox.text) < 0 )
  and (CBox.text <> '')
  then CBox.Items.Insert(0,CBox.text);
end;
procedure delcomboxpd(cbox : tcombobox);
begin
  if cbox.ItemIndex <= cbox.Items.Count
  then CBox.Items.Delete(cbox.ItemIndex);
  CBox.Text := '';
end;
procedure savelistboxpd(cbox : Tlistbox;txt : string);
begin
  cbox.Items.SaveToFile(txt);
end;

procedure loadlistboxpd(cbox : Tlistbox; txt : string);
begin
  if FileExists(txt)
  then cbox.Items.LoadFromFile(txt);
end;

procedure saveMemoboxpd(cbox : TMemo;txt : string);
begin
  cbox.Lines.SaveToFile(txt);
end;

procedure loadMemoboxpd(cbox : TMemo; txt : string);
begin
  if FileExists(txt)
  then cbox.Lines.LoadFromFile(txt);
end;

procedure savecomboxpd(cbox : Tcombobox;txt : string);
begin
  cbox.Items.SaveToFile(txt);
end;

procedure loadcomboxpd(cbox : Tcombobox; txt : string);
begin
  if FileExists(txt)
  then begin
	 cbox.Items.LoadFromFile(txt);
         if cbox.Items.Count > 0
         then cbox.Text := cbox.Items[0];
       end;
end;
procedure CBchange(resultCB:Tcombobox;CB:Tcombobox);
begin
    resultCB.Text:=resultCB.Items[CB.itemindex];
end;

//�õ����ж�����
function getStrcount(s:string):integer;
var sv : string;
    i  : integer;
begin
  sv := s; i := 0;
  if pos(',',sv) > 0
  then repeat
         inc(i);
         delete(sv,1,pos(',',sv));
       until (pos(',',sv) = 0) or (length(sv) < 1);
  result := i;
end;

function addintstrfu(st:string):string;
var i : integer;
begin
  i := strtoint(st);
  inc(i);
  result := inttostr(i);
end;

//������ֵ��1����
function addintstrLNfu(st:string;ln:integer):string;
var i : integer;
begin
  i := strtoint(st);
  inc(i);
  result := FmatIntLen(i,ln);
end;

function FmatIntLen(vl,ln:integer):string;
var s : string;
begin
  s := inttostr(vl);
  if length(s) < ln
  then repeat
	 s := '0' + s ;
       until length(s)= ln
  else if length(s) > ln
       then s := copy(s,1,ln);
  result := s;
end;
function sltDvcfu(var s : string) : string;
var i  : integer;
begin
  i := pos(Dvc,s);
  result := copy(s,1,i-1);
  delete(s,1,i);
end;

function ADDjlhFU(var jlh ,id : Integer) :string;
var ik : integer;
begin
  ik := GetTickCount;// trunc(time*10000000);
  if jlh <> ik
  then begin
         result := floattostr(date) + inttostr(ik) + '00';
         id := 0;
       end
  else begin
         inc(id);
         result := floattostr(date) + inttostr(jlh) + FmatIntLen(id,2);
       end;
  jlh := ik;
end;
//������ڸ�ʽ
function getstr(str:string):string;
begin
  if (length(str)=10)and(pos('-',str)=5)
  then begin
          result:=str[1]+str[2] +str[3]+str[4]+str[6]+str[7]+str[9]+str[10];
        end
  else begin
          showmessage('���ڸ�ʽ����,��תΪ"yyyy-MM-dd"��ʽ');
          result:='datewrong';
        end;


end;
//���ַ�����ĳһ�ض��ַ�ȫ��ɾ��
function DelSubstr(const SubStr,s : string): string;
begin
  Result := s;
  while Pos(SubStr,Result) > 0 do
  begin
    if Pos(SubStr,Result)=1
     then Result := System.Copy(Result,Length(SubStr)+1,Length(Result))
     else Result := System.Copy(Result,1,Pos(SubStr,Result)-1)+System.Copy(Result,Pos(SubStr,Result)+Length(SubStr),Length(Result));
  end;
end;
//�ַ����в���ĳһ�ַ��Ӵ��ĸ���
function CountConstS(const s : string;sourStr : string) : integer;
var
    Str:string;
begin
  Str:=sourStr;
  Result := 0;
  repeat
        if pos(s,str)>0
        then begin
                delete(str,pos(s,str),length(s));
                inc(Result);
               end;
  until pos(s,str)=0
end;
//�ַ����в���ĳһ�ַ��Ӵ��Ĵ��ڵڼ�λ 1��2��3��4��5
function NumConstS(const substr : string;sourStr : string) : integer;
var
    Str,findstr:string;
    i:integer;
function sltnameDvcfu(var s : string) : string;
var i  : integer;
begin
  i := pos(nameDvc,s);
  result := copy(s,1,i-1);
  delete(s,1,i);
end;
begin
  Str:=sourStr;
  i := 0;
  repeat
      findstr := sltnameDvcfu(str);
      inc(i);
      if findstr=substr
      then result:=i
      else result:=0;
  until (findstr=substr)or (pos(substr,str)=0);
end;

function addaftspfu(s:string;i:integer):string;
var g : string;
begin
  if length(s) < i
  then begin
	 repeat
	   s:= s + ' ';
	 until (length(s) >= i);
	 g := s ;
       end
  else g := copy(s,1,i);
  result := g ;
end;

procedure getCBtext(txt:string;cb:Tcombobox);
begin
   cb.ItemIndex := cb.Items.IndexOf(txt);
 end;

 procedure showMsg(s:string);
begin
   application.MessageBox(Pansichar(s),'��������');
end;

procedure DBtoExcel(ExceltemplatePath:string;Eapp:Texcelapplication;Esheet:Texcelworksheet;Adoquy:Tadoquery;Grid:Tdbgrid;firstcol,lastcol:integer);
var
  i,row,column:integer;
begin
   // Eapp.Disconnect;
    Try
    Eapp.Connect;

    Except
    MessageDlg('Excel ����û�б���װ��',
    mtError, [mbOk], 0);
    exit;
    End;

Eapp.Caption:='���ݵ���<Excel>Ӧ��';

if Eapp.Workbooks.Count =0 then
   Eapp.Workbooks.Add(ExceltemplatePath,1)
else begin
      showmsg('��ر�����EXCEL');
      Esheet.Disconnect;
      Eapp.Disconnect;
      exit;
      end;
Esheet.ConnectTo(Eapp.Worksheets[1] as _Worksheet);
row    := 2;
Adoquy.First;
While Not(Adoquy.Eof) do
begin
 column:=1;
 for i:=firstcol to lastcol do
 begin
      Esheet.Cells.Item[row,column]:=Grid.fields[i].AsString;
      column:=column+1;
  end;
  Adoquy.Next;
  row:=row+1;
end;
Eapp.Visible[0]:=True;
end;
function getyear(vdate:Tdatetime):string;
var
  year,month,day:word;
begin
   DecodeDate(vDate,Year, Month, Day) ;
   result:=inttostr(year)+addintstrLNfu(inttostr(month),2)+addintstrLNfu(inttostr(day),2);
end;

/////////////////////////////////////////////////////

end.
