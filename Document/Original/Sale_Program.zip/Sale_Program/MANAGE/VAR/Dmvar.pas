unit dmvar;

interface
uses Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
     DBTables, Db,adodb, ImgList, ActnList,comctrls,inifiles,Variants,lzexpand,QStdCtrls;
{*********************ɾ��**************************}
//ɾ����ǰ��¼
procedure Ddeletepd(Quy:TADOquery );
//�����Ļ
procedure Ddelpm(Quy:TADOquery );

//��ռ�¼
function  DEmptyfu(quy:TADOquery;TabName:string):integer;
function  DExecute(quy:TADOquery;sql:string):integer;
{**********************����******************************}
//����quy����
procedure Dinsert(quy:TADOquery;st:string);
function DInsertfu(quy:TADOquery;values:string;jlh:string='false'):string;
//����sql����
function DinsertQuyfu(Quy : TADOquery ; TableName,values : string):string;
{**********************��ѯ******************************}

//���ֶβ�ѯ
function  DselectMultisfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;tj:string):integer;
//���ֶδ���Χ
function selectMultisfwfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;vZD,vmil,vmax,tj:string):integer;
//���
function  DselectALLfu(Quy:TADOquery; sn , tj : string):integer;
//�Զ����ѯ
function Dselectquy(quy:TADOquery;st:string):integer;

//ģ����ѯ
function DSelectLikefu(quy:TADOquery;sn:string;Mzd,Mval:string;igt:integer;px:string) : integer;

//group like
function DselMulLike_groupfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;tj:string):integer;
//group like date
function DselMulLikedate_groupfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;datezd,dateminval,datemaxval:string;tj:string):integer;

//order ���ֶ�like��ѯ
function DselMulLikefu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;tj:string):integer;
//order like date
function DselMulLikedatefu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;datezd,dateminval,datemaxval:string;tj:string):integer;

//locate��λ��ѯ
function Dlocatefu(quy:TADOquery;Mzd,Mval:string;ln:integer) : integer;
{************************�޸�**********************************}
function DmodifyMulzd(quy:Tadoquery;Xzd,Xvl:string):integer;
//���ֶ���Ļ�޸�
function  Dmodifypm(quy:TADOquery;NameStr,ValStr:string):integer;
{*******************��ֵ*********************************}
//�õ��ֶ��е���Сֵ��10 20 3��result 3
function MixIntCompare(quy:TADOquery;Intzd:string):integer;
//�õ��ֶ��е����ֵ��10 20 3��result 20
function MaxIntCompare(quy:TADOquery;Intzd:string):integer;
//�õ�ʱ���ֶ��е����ʱ��
function MaxTimeCompare(quy:TADOquery;datezd:string):string;
//�õ�ʱ���ֶ��е���Сʱ��
function MinTimeCompare(quy:TADOquery;datezd:string):string;
{���ļ���¼����jlh}
procedure loadfromtext(panel:TstatusPanel;quy:TADOquery;fname:string);
{������¼���ļ�jlh}
procedure SaveTotext(panel:TStatusPanel;quy:TADOquery;fname:string);
var
    fzjlh,fzid:integer;
implementation

uses defVar, stringVar;
function  Dmodifypm(quy:TADOquery;NameStr,ValStr:string):integer;
begin
  result := 0;
  quy.First;
  while not quy.Eof do
  begin
    quy.Edit;
    quy.FieldByName(NameStr).Value := ValStr;
    quy.Post;
    quy.Next;
  end;
end;

function Dselectquy(quy:TADOquery;st:string):integer;
begin

  quy.Close;
  quy.SQL.Clear;
  quy.SQL.Add(st);
  quy.Open;
  quy.First;
  result:=quy.recordcount;
 end;
 
function DInsertfu(quy:TADOquery;values:string;jlh:string='false'):string;
var i  : integer;
    sn,svl : string;
begin
  quy.Insert;
  svl := values;
  result := '';
  i := 0;
  if jlh='false'
  then begin
           while i < quy.FieldCount do
           begin
               sn := quy.Fields.Fields[i].FullName;
               quy.FieldByName(sn).Value := sltDvcfu(svl);
               inc(i);
            end;
        end;
  if jlh='true'
  then begin
            while i <quy.FieldCount-1 do
            begin
              sn := quy.Fields.Fields[i].FullName;
              quy.FieldByName(sn).Value := sltDvcfu(svl);
              inc(i);
            end;
            quy.Fields.Fields[i].AsString:=addjlhfu(fzjlh,fzid);
       end;
  quy.post;
end;

function DinsertQuyfu(Quy : TADOquery ; TableName,values : string):string;
var i  : integer;
    FieldNmaes,
    valueStr : string;
begin
  Quy.Close;
  Quy.SQL.Clear;
  FieldNmaes := ''; valueStr := '';
  i := 0;
  while i < (Quy.FieldCount-1) do
  begin
    FieldNmaes := FieldNmaes + Quy.Fields.Fields[i].FullName +',' ;
    valueStr   := valueStr + sltDvcfu(values) + ',';
    inc(i);
  end;
  delete(valueStr,length(valueStr),1);
  delete(FieldNmaes,length(FieldNmaes),1);
  Quy.SQL.Add('insert into '+ TableName +' ( ' + FieldNmaes + ') values (' + valueStr + ')');
  Quy.ExecSQL;
end;
procedure Dinsert(quy:TADOquery;st:string);
var i   : integer;
    sltstr   : string;
begin
    i:=0;
    quy.Insert;
    while i < (quy.FieldCount) do
    begin
      sltstr:=sltdvcfu(st);
      if (quy.Fields[i].DataType =FTdate)or(quy.Fields[i].DataType =FTdatetime)
      then begin
                if pos('-',sltstr)=0
                then begin
                        showmessage('�������Ͳ������');
                        exit;
                       end;
             end;
      quy.Fields[i].Value:=  sltstr;
      inc(i);
    end;
    quy.Post;
 end;
function DselectMultisfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;tj:string):integer;
var i : integer;
    svn,svz,sxz: string;
    gs : string;
begin
  result := 0;
  svn := mzd;
  svz := mval; sxz := '';
  if svn = ''
  then begin
         messagedlg('û��ѡ���ֶ�!',mtinformation,[mbok],0);
         Exit;
       end;
  i := 1;
  repeat
    gs := sltdvcfu(svn);
    sxz := sxz + gs + ' =' +chr(39)+ sltdvcfu(svz)+ chr(39)+' and ' ;
    inc(i);
  until i > ln;
  delete(sxz,length(sxz)-3,4);
  quy.Close;
  quy.SQL.Clear;
  if tj <> ''
  then quy.SQL.Add('select * from ' + sn + ' where ' + sxz + ' order by ' + tj )
  else quy.SQL.Add('select * from ' + sn + ' where ' + sxz );
  quy.Active := true;
  quy.First;
  result:=0;
  while not quy.Eof do
  begin
     inc(result) ;
     quy.Next    ;
   end;
   quy.First;
  //result := quy.RecordCount;
end;
{ѡ����ֶη�Χ��ѯ���������ֶΣ���Ҫ���� ����� sn
�ֶ��� Mzd  := 'aaa,bbb,ccc,'
�ֶ�ֵ Mval := 'aaa,bbb,ccc' ����ѯ�ĳ��� ln
�ֶ��� Mzd  := 'aaa'
�ֶ�Сֵ vmil := 'aaa'
�ֶ�Сֵ vmax := 'aaa'
���� order by �ֶ���1,�ֶ���2,�ֶ���3}
function selectMultisfwfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;vZD,vmil,vmax,tj:string):integer;
var i : integer;
    svn,svz,sxz : string;
    gs : string;
begin
  result := 0;
  svn := mzd;
  svz := mval; sxz := '';
  if svn = ''
  then begin
         messagedlg('û��ѡ���ֶ�!',mtinformation,[mbok],0);
         Exit;
       end;
  if (vmil = '' ) or ( vmax = '' ) or ( vZD = '' )
  then begin
         messagedlg('û��ѡ��Χֵ!',mtinformation,[mbok],0);
         Exit;
       end;
  i := 1;
  repeat
    gs := sltfu(svn);
    sxz := sxz + gs + ' =' +chr(39)+ sltfu(svz)+ chr(39)+' and ' ;
    inc(i);
  until i > ln;
  sxz := sxz +  ' ( '+ vZD + ' >='+chr(39)+vmil+chr(39)+' ) and ( ' + vZD + ' <='+chr(39)+vmax+chr(39)+') ' ;
  quy.Close;
  quy.SQL.Clear;
  quy.SQL.Add('select * from ' + sn + ' where ' + sxz + ' order by'+tj );

  quy.Active := true;
  result := quy.RecordCount;
end;



function DselMulLikefu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;tj:string):integer;
var i : integer;
    svn,svz,sxz: string;
    gs : string;
begin
  result := 0;
  svn := mzd;
  svz := mval; sxz := '';
  if svn = ''
  then begin
         messagedlg('û��ѡ���ֶ�!',mtinformation,[mbok],0);
         Exit;
       end;
  i := 1;
  repeat
    gs := sltdvcfu(svn);
    sxz := sxz + gs + '  LIKE ' +chr(39)+ '%'+sltdvcfu(svz)+ '%'+chr(39)+' and ' ;
    inc(i);
  until i > ln;
  delete(sxz,length(sxz)-3,4);
  quy.Close;
  quy.SQL.Clear;
  if tj <> ''

  then quy.SQL.Add('select * from ' + sn + ' where ' + sxz + ' order by ' + tj )
  else quy.SQL.Add('select * from ' + sn + ' where ' + sxz );
  quy.Active := true;
  quy.First;
  result := quy.RecordCount;
end;
function DselMulLikedatefu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;datezd,dateminval,datemaxval:string;tj:string):integer;
var i : integer;
    svn,svz,sxz: string;
    gs : string;
begin
  result := 0;
  svn := mzd;
  svz := mval; sxz := '';
  if svn = ''
  then begin
         messagedlg('û��ѡ���ֶ�!',mtinformation,[mbok],0);
         Exit;
       end;
  i := 1;
  repeat
    gs := sltdvcfu(svn);
    sxz := sxz + gs + '  LIKE ' +chr(39)+ '%'+sltdvcfu(svz)+ '%'+chr(39)+' and ' ;
    inc(i);
  until i > ln;
  delete(sxz,length(sxz)-3,4);
  quy.Close;
  quy.SQL.Clear;
  if tj <> ''

  then quy.SQL.Add('select * from ' + sn + ' where ' + sxz + ' and ('+datezd+'>='+quotedstr(dateminval)+'and '+datezd+'<='+quotedstr(datemaxval)+') order by ' + tj )
  else quy.SQL.Add('select * from ' + sn + ' where ' + sxz + ' and ('+datezd+'>='+quotedstr(dateminval)+'and '+datezd+'<='+quotedstr(datemaxval)+')');
  quy.Active := true;
  quy.First;
  result := quy.RecordCount;
end;
function DselectALLfu(Quy:TADOquery; sn , tj : string):integer;
begin
  quy.Close;
  quy.SQL.Clear;
  if tj <> ''
  then quy.SQL.Add('select * from ' + sn + ' order by '+ tj )
  else quy.SQL.Add('select * from ' + sn  );
  quy.Active := true;
  quy.First;
  result := quy.RecordCount;
end;
procedure Ddeletepd(Quy:TADOquery );
begin
  if quy.IsEmpty=false
  then
  quy.Delete;
end;

procedure Ddelpm(Quy:TADOquery );
begin
   quy.first;
   while not quy.Eof
   do begin
        quy.Delete;
       end;
 end;

function DSelectLikefu(quy:TADOquery;sn:string;Mzd,Mval:string;igt:integer;px:string) : integer;
var StrSQL,StrWhere,StrQ,Str : string;
begin
  StrQ := '"';  Str := '';
  case igt of
     0 : StrWhere := Mzd + ' =        ' + Str  + Mval + Str;
     1 : StrWhere := Mzd + ' <>       ' + Str  + Mval + Str;
     2 : StrWhere := Mzd + ' <        ' + Str  + Mval + Str;
     3 : StrWhere := Mzd + ' <=       ' + Str  + Mval + Str;
     4 : StrWhere := Mzd + ' >        ' + Str  + Mval + Str;
     5 : StrWhere := Mzd + ' >=       ' + Str  + Mval + Str;
     6 : StrWhere := Mzd + ' LIKE     ' + StrQ + Mval + '%'  + StrQ;
     7 : StrWhere := Mzd + ' NOT LIKE ' + StrQ + Mval + '%'  + StrQ;
     8 : StrWhere := Mzd + ' LIKE     ' + StrQ + '%'  + Mval + StrQ;
     9 : StrWhere := Mzd + ' NOT LIKE ' + StrQ + '%'  + Mval + StrQ;
    10 : StrWhere := Mzd + ' LIKE     ' + StrQ + '%'  + Mval + '%' + StrQ;
    11 : StrWhere := Mzd + ' NOT LIKE ' + StrQ + '%'  + Mval + '%' + StrQ;
    12 : StrWhere := Mzd + ' IS NULL  '  ;
    13 : StrWhere := Mzd + ' IS NOT NULL';
end;
 if px=''
 then  StrSQL := ' SELECT * FROM ' + sn + ' WHERE ' + StrWhere
 else  StrSQL := ' SELECT * FROM ' + sn + ' WHERE ' + StrWhere+' order by '+px;
  quy.Close;
  quy.SQL.Clear;
  quy.SQL.Add(strsql);
  quy.Open;
  result := quy.RecordCount;
end;

function Dlocatefu(quy:TADOquery;Mzd,Mval:string;ln:integer) : integer;
var iMzd,iMval,
    zd  : string;
    i   : integer;
    Sy  : array[0..9] of string;
begin
if quy.IsEmpty
then begin
      showmessage('û���ִ˼�¼');
      result:=0;
      exit;
     end;
  iMzd  := Mzd ;
  iMval := Mval;
  i := 1;
  repeat
    zd := zd + sltDvcfu(iMzd)+';';
    inc(i);
  until i > ln ;
  delete(zd,length(zd),1);
  i := 1;
  repeat
    Sy[i-1] := sltDvcfu(iMval);
    inc(i);
  until i > ln;

  case ln of
  1 : QUY.Locate(zd,vararrayof([Sy[0]]),[]);
  2 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1]]),[]);
  3 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1],Sy[2]]),[]);
  4 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1],Sy[2],Sy[3]]),[]);
  5 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1],Sy[2],Sy[3],Sy[4]]),[]);
  6 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1],Sy[2],Sy[3],Sy[4],Sy[5]]),[]);
  7 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1],Sy[2],Sy[3],Sy[4],Sy[5],Sy[6]]),[]);
  8 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1],Sy[2],Sy[3],Sy[4],Sy[5],Sy[6],Sy[7]]),[]);
  9 : QUY.Locate(zd,vararrayof([Sy[0],Sy[1],Sy[2],Sy[3],Sy[4],Sy[5],Sy[6],Sy[7],Sy[8]]),[]);
  end;
  result := quy.RecNo;
end;
function DmodifyMulzd(quy:Tadoquery;Xzd,Xvl:string):integer;
var Sg,Szd,Svl : string;
begin
  result :=0;
  quy.Edit;
  Szd := Xzd; Svl := Xvl;
  repeat
    Sg := SltDvcfu(Szd);
    quy.FieldByName(Sg).Value := SltDvcfu(Svl);
  until pos(Dvc,Szd) < 1;
  quy.Post;
end;


function  DEmptyfu(quy:TADOquery;TabName:string):integer;
begin
  result := 0;
  try
    quy.Close;
    quy.SQL.Clear;
    quy.SQL.Add(' delete from ' + TabName);
    quy.ExecSQL;
  except
    result := 1;
  end;
end;
function  DExecute(quy:TADOquery;sql:string):integer;
begin
  result := 0;
  try
    quy.Close;
    quy.SQL.Clear;
    quy.SQL.Add(sql);
    quy.ExecSQL;
  except
    result := 1;
  end;
end;
//�õ�ʱ���ֶ��е���Сʱ��
function MinTimeCompare(quy:TADOquery;datezd:string):string;
var
  mindate,curdate:Tdate;
begin
   if quy.IsEmpty=true
   then begin
           result:=datetimetostr(now);
         end
   else begin
           quy.First;
           mindate := quy.fieldbyname(datezd).AsDateTime;
           while not quy.Eof do
            begin
                curdate := quy.fieldbyname(datezd).AsDateTime;
                if curdate<=mindate
                then mindate:=curdate;
                quy.next;
             end;
           quy.First;
           result := datetimetostr(mindate);
         end;  
end;

//�õ�ʱ���ֶ��е����ʱ��
function MaxTimeCompare(quy:TADOquery;datezd:string):string;
var
 maxdate,curdate:Tdate;
begin
   quy.First;
   maxdate := quy.fieldbyname(datezd).AsDateTime;
   while not quy.Eof do
    begin
        curdate := quy.fieldbyname(datezd).AsDateTime;
        if curdate>=maxdate
        then maxdate:=curdate;
        quy.next;
     end;
   quy.First;
   result := datetimetostr(maxdate);
end;

//�õ��ֶ��е����ֵ��10 20 3��result 20
function MaxIntCompare(quy:TADOquery;Intzd:string):integer;
var
 maxInt,curInt:integer;
begin
   if quy.IsEmpty=true
   then begin
           result:=0;
         end
   else begin
             quy.First;
             maxInt := quy.fieldbyname(Intzd).AsInteger;
             while not quy.Eof do
             begin
                curInt := quy.fieldbyname(Intzd).AsInteger;
                if curInt>=maxInt
                then maxInt:=curInt;
                quy.next;
             end;
             quy.First;
             result := maxInt;
        end;
end;

//�õ��ֶ��е����ֵ��10 20 3��result 3
function MixIntCompare(quy:TADOquery;Intzd:string):integer;
var
  MixInt,curInt:integer;
begin
   quy.First;
   MixInt := quy.fieldbyname(Intzd).asinteger;
   while not quy.Eof do
    begin
        curInt := quy.fieldbyname(Intzd).AsInteger;
        if curInt<=MixInt
        then MixInt:=curInt;
        quy.next;
     end;
   quy.First;
   result := MixInt;
end;


{���ļ���¼����jlh}
procedure loadfromtext(panel:TstatusPanel;quy:TADOquery;fname:string);
var txt : textfile;
    gs,s  : string;
    i,j   : integer;
begin
  if not FileExists(fname)
  then Exit;
  try
  assignfile(txt,fname);
  reset(txt); j := 0;
  while not Eof(txt) do
  begin
    readln(txt,gs); inc(j);
    Panel.text := gs;
    quy.Insert;
    try
    i := 0;
    while i < (quy.FieldCount-1) do
    begin
      s := sltfu(gs);
      if (quy.Fields.Fields[i].DataType = ftDate) or
         (quy.Fields.Fields[i].DataType = ftDatetime )
      then begin
             if s = ''
             then quy.Fields.Fields[i].Value := '1900-01-01'
             else quy.Fields.Fields[i].Value := strtodate(s);
           end
      else quy.Fields.Fields[i].Value := s;
      inc(i);
    end;
    quy.Fields.Fields[i].AsString := addjlhfu(fzjlh,fzid);
    quy.Post;
    except
      messagedlg('�����ļ�����!!! �ڡ�' + inttostr(j)+ '����!',mtinformation,[mbok],0);
      Panel.text := gs ;
      break;
    end;
  end;
  finally
    closefile(txt);
    Panel.text := gs ;
  end;
end;
{������¼���ļ�jlh}
procedure SaveTotext(panel:TStatusPanel;quy:TADOquery;fname:string);
var txt : textfile;
    gs  : string;
    i   : integer;
begin
  if quy.IsEmpty
  then exit;
  assignfile(txt,fname);
  rewrite(txt);
  while not Quy.Eof do
  begin
    i := 0; gs := '';
    while i < quy.FieldCount do
    begin
      gs := gs + quy.Fields.Fields[i].AsString  + Dvc;
      inc(i);
    end;
    writeln(txt,gs);
    panel.Text := gs;
    Quy.Next;
  end;
  closefile(txt);
end;
{********************}
function DselMulLikedate_groupfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;datezd,dateminval,datemaxval:string;tj:string):integer;
var i : integer;
    svn,svz,sxz: string;
    gs : string;
begin
  result := 0;
  svn := mzd;
  svz := mval; sxz := '';
  if svn = ''
  then begin
         messagedlg('û��ѡ���ֶ�!',mtinformation,[mbok],0);
         Exit;
       end;
  i := 1;
  repeat
    gs := sltdvcfu(svn);
    sxz := sxz + gs + '  LIKE ' +chr(39)+ '%'+sltdvcfu(svz)+ '%'+chr(39)+' and ' ;
    inc(i);
  until i > ln;
  delete(sxz,length(sxz)-3,4);
  quy.Close;
  quy.SQL.Clear;
  if tj <> ''

  then quy.SQL.Add('select ' + tj + ', count('+tj+') as b from ' + sn + ' where ' + sxz + ' and ('+datezd+'>='+quotedstr(dateminval)+'and '+datezd+'<='+quotedstr(datemaxval)+') group by '+tj+' order by b' )
  else showmessage('��ѡ������ֶ�');
  quy.Active := true;
  quy.First;
  result := quy.RecordCount;
end;
function DselMulLike_groupfu(Quy:TADOquery;sn,Mzd,Mval:string;ln:integer;tj:string):integer;
var i : integer;
    svn,svz,sxz: string;
    gs : string;
begin
  result := 0;
  svn := mzd;
  svz := mval; sxz := '';
  if svn = ''
  then begin
         messagedlg('û��ѡ���ֶ�!',mtinformation,[mbok],0);
         Exit;
       end;
  i := 1;
  repeat
    gs := sltdvcfu(svn);
    sxz := sxz + gs + '  LIKE ' +chr(39)+ '%'+sltdvcfu(svz)+ '%'+chr(39)+' and ' ;
    inc(i);
  until i > ln;
  delete(sxz,length(sxz)-3,4);
  quy.Close;
  quy.SQL.Clear;
  if tj <> ''

  then quy.SQL.Add('select ' + tj + ', count('+tj+')  b from ' + sn + ' where ' + sxz + ' group by '+px+' order by b' )
  else showmessage('��ѡ������ֶ�');
  quy.Active := true;
  quy.First;
  result := quy.RecordCount;
end;
{******************************}

end.
