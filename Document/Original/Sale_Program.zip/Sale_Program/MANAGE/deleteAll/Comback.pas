unit comback;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Buttons, ExtCtrls, ComCtrls;

type
  Tfmcomback = class(TForm)
    bar: TStatusBar;
    Panel1: TPanel;
    Label1: TLabel;
    showhint: TMemo;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    BitBtn3: TBitBtn;
    cbunderpantype: TEdit;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure BitBtn3Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  fmcomback: Tfmcomback;

implementation

uses defvar, dmvar, managedmu, stringVar;

{$R *.dfm}

procedure Tfmcomback.FormClose(Sender: TObject; var Action: TCloseAction);
begin
action:=cafree;
end;

procedure Tfmcomback.BitBtn3Click(Sender: TObject);
begin
close;
end;

procedure Tfmcomback.BitBtn1Click(Sender: TObject);

begin
showhint.Text:='';
if Dselectquy(managedm.quy,'select * from tb_stock_out where underpantype='+QuotedStr(cbunderpantype.Text))<>0
then begin
        showhint.Text:='�˳��ڳ������У������Ѿ��۳�!';
        exit;
      end

else if Dselectquy(managedm.quy,'select * from tb_stock where underpantype='+QuotedStr(cbunderpantype.Text))<>0
then begin
        showhint.Text:='�˳��ڿ���У���λ��'+managedm.quy.fieldbyname('stockplace').asstring;
       end

else if  Dselectquy(managedm.quy,'select * from tb_stock_in where underpantype='+QuotedStr(cbunderpantype.Text))<>0
then showhint.Text:='�˳��ڽ������У���û����⣡'


else showhint.Text:='�ڽ���������棬��������û�鵽�˳���' ;
end;

procedure Tfmcomback.BitBtn2Click(Sender: TObject);
 
begin


if Dselectquy(managedm.quy,'select * from tb_stock_in where underpantype='+QuotedStr(cbunderpantype.Text))<>0
then begin
        //��ʼ
        if (managedm.quy.fieldbyname('inpath').AsString='����') and (length(managedm.quy.fieldbyname('jcunderpantype').AsString)>5)
        then begin
                showMsg('�˽��복�Ѿ�����,���ܹ�˾�˳�!');
                exit;
              end;
        //����

        if (managedm.quy.FieldByName('inpath').AsString='����') and (length(managedm.quy.FieldByName('jcunderpantype').AsString)>5)
        then begin
                if dmvar.Dselectquy(managedm.quy,'select * from tb_stock_out where underpantype='+quotedstr(managedm.inquy.FieldByName('jcunderpantype').AsString))>0
                then begin
                       managedm.quy.Edit;
                       managedm.quy.FieldByName('hrunderpantype').AsString:='';
                       managedm.quy.FieldByName('bz').AsString:='';
                       managedm.quy.Post;
                     end
                else showMsg('���ݲ�һ��,����������ִ��,���ס�˳����̺�,ѯ�ʹ���Ա!');
              end;
     end;
     try
       managedm.quy.Close;
       managedm.quy.SQL.Clear ;
       managedm.quy.SQL.Add('delete from tb_xsclient     where          dph='+quotedStr(cbunderpantype.Text)) ;
       managedm.quy.SQL.Add('delete from tb_allfit       where underpantype='+quotedStr(cbunderpantype.Text)) ;
       managedm.quy.SQL.Add('delete from tb_stock_change where underpantype='+quotedStr(cbunderpantype.Text)) ;
       managedm.quy.SQL.Add('delete from tb_stock_out    where underpantype='+quotedStr(cbunderpantype.Text)) ;
       managedm.quy.SQL.Add('delete from tb_stock        where underpantype='+quotedStr(cbunderpantype.Text)) ;
       managedm.quy.SQL.Add('delete from tb_stock_in     where underpantype='+quotedStr(cbunderpantype.Text)) ;
       managedm.quy.ExecSQL;
     except

       end;

showmsg('����������') ;
end;

end.
