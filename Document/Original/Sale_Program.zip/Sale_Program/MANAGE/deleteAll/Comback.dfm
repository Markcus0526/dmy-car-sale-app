object fmcomback: Tfmcomback
  Left = 236
  Top = 107
  Width = 359
  Height = 229
  BorderIcons = [biSystemMenu]
  Caption = #36710#20457#31649#29702#27169#22359
  Color = clBtnFace
  Font.Charset = GB2312_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = #23435#20307
  Font.Style = []
  OldCreateOrder = False
  Position = poMainFormCenter
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 12
  object bar: TStatusBar
    Left = 0
    Top = 183
    Width = 351
    Height = 19
    Panels = <>
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 351
    Height = 183
    Align = alClient
    BevelInner = bvLowered
    TabOrder = 1
    object Label1: TLabel
      Left = 17
      Top = 29
      Width = 84
      Height = 12
      Caption = #35831#36755#20837#24213#30424#21495#65306
    end
    object showhint: TMemo
      Left = 98
      Top = 57
      Width = 231
      Height = 80
      ImeName = #20013#25991' ('#31616#20307') - '#24494#36719#25340#38899
      ReadOnly = True
      TabOrder = 0
    end
    object BitBtn1: TBitBtn
      Left = 95
      Top = 146
      Width = 62
      Height = 25
      Caption = #36864#36710#25628#32034
      TabOrder = 1
      OnClick = BitBtn1Click
    end
    object BitBtn2: TBitBtn
      Left = 174
      Top = 146
      Width = 63
      Height = 25
      Caption = #20844#21496#36864#36710
      TabOrder = 2
      OnClick = BitBtn2Click
    end
    object BitBtn3: TBitBtn
      Left = 261
      Top = 146
      Width = 69
      Height = 24
      Caption = #36820#22238#31995#32479
      TabOrder = 3
      OnClick = BitBtn3Click
    end
    object cbunderpantype: TEdit
      Left = 97
      Top = 25
      Width = 232
      Height = 20
      ImeName = #20013#25991' ('#31616#20307') - '#24494#36719#25340#38899
      TabOrder = 4
    end
  end
end
